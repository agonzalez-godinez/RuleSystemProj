from django.utils import timezone
import pytz


class BlogUtils:
    # https://stackoverflow.com/questions/16603645/how-to-convert-datetime-time-from-utc-to-different-timezone
    def utc_to_time(self, timezone='America/Chicago'):
        return self.replace(tzinfo=pytz.utc).astimezone(pytz.timezone(timezone))
