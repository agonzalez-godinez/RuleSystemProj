from . import views
from django.urls import path, re_path

app_name = 'rule_system'
urlpatterns = [
path('', views.home, name='home'),
    re_path(r'^home/$', views.home, name='home'),
    path('login/', views.user_login, name='login'),
    path('register/', views.register, name='register'),
    path('rule_list', views.rule_list, name='rule_list'),
    path('<int:year>/<int:month>/<int:day>/<slug:post>/',
         views.rule_detail,
         name='rule_detail'),
    path('rule/create/', views.rule_new, name='rule_new'),
    path('rule/<int:pk>/edit/', views.rule_edit, name='rule_edit'),
    path('rule/<int:pk>/delete/', views.rule_delete, name='rule_delete'),

]