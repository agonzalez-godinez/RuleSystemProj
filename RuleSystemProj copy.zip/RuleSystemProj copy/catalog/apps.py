from django.apps import AppConfig

class RulesConfig(AppConfig):
    default_field = 'django.db.models.BigAutoField'
    name = 'rule_system'