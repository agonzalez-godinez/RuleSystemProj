from django.contrib import admin
#from .models import

#@admin.register()
class Admin(admin.ModelAdmin):
    something = ()